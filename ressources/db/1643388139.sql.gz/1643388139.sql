--
-- PostgreSQL database dump
--

-- Dumped from database version 13.5
-- Dumped by pg_dump version 13.5

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public.unwanted_number DROP CONSTRAINT unwanted_number_pkey;
ALTER TABLE ONLY public.trecord DROP CONSTRAINT trecord_pkey;
ALTER TABLE ONLY public.dump_t DROP CONSTRAINT dump_t_pkey;
ALTER TABLE ONLY public.dump_huri DROP CONSTRAINT dump_huri_pkey;
ALTER TABLE ONLY public.cperson DROP CONSTRAINT cperson_pkey;
ALTER TABLE public.trecord ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dump_t ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.dump_huri ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.unwanted_number_id_seq;
DROP TABLE public.unwanted_number;
DROP SEQUENCE public.trecord_id_seq;
DROP TABLE public.trecord;
DROP SEQUENCE public.dump_t_id_seq;
DROP TABLE public.dump_t;
DROP SEQUENCE public.dump_huri_id_seq;
DROP TABLE public.dump_huri;
DROP SEQUENCE public.cperson_id_seq;
DROP TABLE public.cperson;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: cperson; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.cperson (
    id integer NOT NULL,
    c_number character varying(255) NOT NULL,
    a_nom character varying(255) DEFAULT NULL::character varying,
    c_adress character varying(255) DEFAULT NULL::character varying,
    c_operator character varying(255) NOT NULL,
    c_file_name character varying(255) NOT NULL,
    c_pic_name character varying(255) DEFAULT 'icon-default.png'::character varying
);


ALTER TABLE public.cperson OWNER TO admin;

--
-- Name: cperson_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.cperson_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.cperson_id_seq OWNER TO admin;

--
-- Name: dump_huri; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.dump_huri (
    id integer NOT NULL,
    num_a character varying(255) NOT NULL,
    num_b character varying(255) NOT NULL,
    a_nom text,
    b_nom text,
    duration integer NOT NULL,
    day_time timestamp(0) without time zone NOT NULL,
    flux_appel character varying(255) NOT NULL,
    data_type character varying(255) NOT NULL
);


ALTER TABLE public.dump_huri OWNER TO admin;

--
-- Name: dump_huri_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.dump_huri_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dump_huri_id_seq OWNER TO admin;

--
-- Name: dump_huri_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.dump_huri_id_seq OWNED BY public.dump_huri.id;


--
-- Name: dump_t; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.dump_t (
    id integer NOT NULL,
    flux_appel character varying(255) NOT NULL,
    data_type character varying(255) NOT NULL,
    day_time timestamp(0) without time zone NOT NULL,
    duration integer NOT NULL,
    imei character varying(255) DEFAULT NULL::character varying,
    num_a character varying(255) NOT NULL,
    num_b character varying(255) NOT NULL,
    cell_id character varying(255) DEFAULT NULL::character varying,
    location_num_a character varying(255) DEFAULT NULL::character varying,
    brand character varying(255) DEFAULT NULL::character varying,
    os character varying(255) DEFAULT NULL::character varying,
    model character varying(255) DEFAULT NULL::character varying,
    a_nom text,
    a_piece character varying(255) DEFAULT NULL::character varying,
    a_adresse character varying(255) DEFAULT NULL::character varying,
    b_nom text,
    b_piece character varying(255) DEFAULT NULL::character varying,
    b_adresse character varying(255) DEFAULT NULL::character varying
);


ALTER TABLE public.dump_t OWNER TO admin;

--
-- Name: dump_t_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.dump_t_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.dump_t_id_seq OWNER TO admin;

--
-- Name: dump_t_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.dump_t_id_seq OWNED BY public.dump_t.id;


--
-- Name: trecord; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.trecord (
    id integer NOT NULL,
    data_type character varying(255) NOT NULL,
    flux_appel character varying(255) NOT NULL,
    num_a character varying(255) NOT NULL,
    num_b character varying(255) NOT NULL,
    a_nom text,
    b_nom text,
    duration integer NOT NULL,
    day_time timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.trecord OWNER TO admin;

--
-- Name: trecord_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.trecord_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.trecord_id_seq OWNER TO admin;

--
-- Name: trecord_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: admin
--

ALTER SEQUENCE public.trecord_id_seq OWNED BY public.trecord.id;


--
-- Name: unwanted_number; Type: TABLE; Schema: public; Owner: admin
--

CREATE TABLE public.unwanted_number (
    id integer NOT NULL,
    number character varying(255) NOT NULL,
    unwanted_rows_count integer DEFAULT 0 NOT NULL,
    description text,
    created_at timestamp(0) without time zone NOT NULL
);


ALTER TABLE public.unwanted_number OWNER TO admin;

--
-- Name: unwanted_number_id_seq; Type: SEQUENCE; Schema: public; Owner: admin
--

CREATE SEQUENCE public.unwanted_number_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.unwanted_number_id_seq OWNER TO admin;

--
-- Name: dump_huri id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.dump_huri ALTER COLUMN id SET DEFAULT nextval('public.dump_huri_id_seq'::regclass);


--
-- Name: dump_t id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.dump_t ALTER COLUMN id SET DEFAULT nextval('public.dump_t_id_seq'::regclass);


--
-- Name: trecord id; Type: DEFAULT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.trecord ALTER COLUMN id SET DEFAULT nextval('public.trecord_id_seq'::regclass);


--
-- Data for Name: cperson; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.cperson (id, c_number, a_nom, c_adress, c_operator, c_file_name, c_pic_name) FROM stdin;
\.


--
-- Data for Name: dump_huri; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.dump_huri (id, num_a, num_b, a_nom, b_nom, duration, day_time, flux_appel, data_type) FROM stdin;
\.


--
-- Data for Name: dump_t; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.dump_t (id, flux_appel, data_type, day_time, duration, imei, num_a, num_b, cell_id, location_num_a, brand, os, model, a_nom, a_piece, a_adresse, b_nom, b_piece, b_adresse) FROM stdin;
\.


--
-- Data for Name: trecord; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.trecord (id, data_type, flux_appel, num_a, num_b, a_nom, b_nom, duration, day_time) FROM stdin;
\.


--
-- Data for Name: unwanted_number; Type: TABLE DATA; Schema: public; Owner: admin
--

COPY public.unwanted_number (id, number, unwanted_rows_count, description, created_at) FROM stdin;
\.


--
-- Name: cperson_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.cperson_id_seq', 1, false);


--
-- Name: dump_huri_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.dump_huri_id_seq', 1, false);


--
-- Name: dump_t_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.dump_t_id_seq', 1, false);


--
-- Name: trecord_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.trecord_id_seq', 1, false);


--
-- Name: unwanted_number_id_seq; Type: SEQUENCE SET; Schema: public; Owner: admin
--

SELECT pg_catalog.setval('public.unwanted_number_id_seq', 1, false);


--
-- Name: cperson cperson_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.cperson
    ADD CONSTRAINT cperson_pkey PRIMARY KEY (id);


--
-- Name: dump_huri dump_huri_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.dump_huri
    ADD CONSTRAINT dump_huri_pkey PRIMARY KEY (id);


--
-- Name: dump_t dump_t_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.dump_t
    ADD CONSTRAINT dump_t_pkey PRIMARY KEY (id);


--
-- Name: trecord trecord_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.trecord
    ADD CONSTRAINT trecord_pkey PRIMARY KEY (id);


--
-- Name: unwanted_number unwanted_number_pkey; Type: CONSTRAINT; Schema: public; Owner: admin
--

ALTER TABLE ONLY public.unwanted_number
    ADD CONSTRAINT unwanted_number_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

